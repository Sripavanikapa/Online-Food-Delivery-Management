import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginPage from './components/Login/LoginPage';
import MainRestaurant from './components/restaurant/MainRestaurant';
import RegisterPage from './components/register/RegisterPage';
import CustProfile from './components/Customer/CustProfile/CustProfile';
import UpdateRestaurantStatus from './components/restaurant/UpdateRestaurantStatus';
import CustHome  from './components/Customer/CustHome';
import Landing from './components/Landing/Landing';
import Cart from './components/Customer/Cart/Cart'
import CustSearchBar from './components/Customer/CustSearchBar/CustSearchBar';
import FoodByCategory from './components/Customer/FoodByCategory/FoodByCategory';
import PrivateRoute from './components/PrivateRoute';
import CustOrders from './components/Customer/CustGetOrders/CustOrders'
import OrderNow from './components/Customer/OrderNow/OrderNow';
function App() {
  return (
   
    <Router>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/restaurant/*" element={<MainRestaurant />} />
        <Route path="/profile" element={<PrivateRoute><CustProfile/></PrivateRoute>}/>
         <Route path="/register" element={<RegisterPage />} />
         <Route path="/customer" element={<CustHome />} />
         <Route path="/fooditems/results" element={<CustSearchBar />} />
         <Route path="/fooditems/category" element={<FoodByCategory />} />
         <Route path="/ordernow" element={<PrivateRoute><OrderNow /></PrivateRoute>} />
         <Route path="/orders" element={<PrivateRoute><CustOrders /></PrivateRoute>} />
         <Route path="/cart" element={<Cart/>}></Route>
          {/* <Route path="/foods/:categoryName" element={<FoodList />} /> */}
      </Routes>
    </Router>
   
  );
}

export default App;
