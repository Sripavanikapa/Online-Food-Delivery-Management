import React, { useEffect, useState } from 'react';
import './RestaurantProfile.css';

const RestaurantProfile = () => {
  const [profile, setProfile] = useState(null);
  const [address, setAddress] = useState(null);
  const [orderCount, setOrderCount] = useState(0);
  const [newAddress, setNewAddress] = useState('');
  const [showAddressForm, setShowAddressForm] = useState(false);

  const token = localStorage.getItem('token');
  const restaurantId = localStorage.getItem('userId');

  // Fetch restaurant profile
  useEffect(() => {
    fetch('https://localhost:7025/api/Restaurant/me', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => {
        console.log("Fetched profile:", data);
        setProfile(data);
      })
      .catch(err => console.error('Failed to fetch profile:', err));
  }, [token]);

  // Fetch address and order history
  useEffect(() => {
    if (!profile || !profile.phoneno) return;

    // Fetch address list
    fetch(`https://localhost:7025/api/Customer/Saved Addresses?phno=${profile.phoneno}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => {
        console.log("Fetched Address:", data);
        if (data.length === 1) {
          setAddress({ Address1: data[0].address1, Address2: null });
        } else if (data.length >= 2) {
          setAddress({ Address1: data[0].address1, Address2: data[1].address1 });
        } else {
          setAddress(null);
        }
      })
      .catch(err => console.error('Failed to fetch address:', err));

    // Fetch order history and count accepted orders
    fetch(`https://localhost:7025/api/Restaurant/order-history/${restaurantId}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(async res => {
        const contentType = res.headers.get('content-type');
        if (!res.ok) {
          const text = await res.text();
          throw new Error(`Order history fetch failed: ${text}`);
        }

        if (contentType && contentType.includes('application/json')) {
          const data = await res.json();
          const acceptedOrders = data.filter(order => order.status === "Accepted");
          setOrderCount(acceptedOrders.length);
        } else {
          const text = await res.text();
          console.warn("Non-JSON response:", text);
          setOrderCount(0);
        }
      })
      .catch(err => console.error('Failed to fetch order history:', err));
  }, [token, restaurantId, profile]);

  // Add address logic
  const addAddress = async () => {
    if (!profile.phoneno || !newAddress.trim()) {
      alert('Phone number and address are required.');
      return;
    }

    const isNewUser = !address?.Address1;
    const isSecondSlotAvailable = address?.Address1 && !address?.Address2;

    const query = new URLSearchParams({
      Phno: profile.phoneno,
      Address1: isNewUser ? newAddress.trim() : address.Address1,
      Address2: isSecondSlotAvailable ? newAddress.trim() : "N/A"
    });

    try {
      const response = await fetch(`https://localhost:7025/api/Address/create/address?${query.toString()}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });

      if (response.ok) {
        alert('Address added successfully!');
        const updatedAddress = {
          Address1: isNewUser ? newAddress.trim() : address.Address1,
          Address2: isSecondSlotAvailable ? newAddress.trim() : address.Address2
        };
        setAddress(updatedAddress);
        setNewAddress('');
        setShowAddressForm(false);
      } else {
        const errorData = await response.json();
        const errorMessages = Object.entries(errorData.errors || {})
          .map(([field, messages]) => `${field}: ${messages.join(', ')}`)
          .join('\n');
        alert(`Validation Error:\n${errorMessages}`);
      }
    } catch (error) {
      console.error('Add address error:', error);
      alert('Something went wrong');
    }
  };

  const shouldShowAddButton = !address || (address.Address1 && !address.Address2);

  if (!profile) return <div>Loading profile...</div>;

  return (
    <div className="restaurant-profile">
      <div className="profile-header">
        <h3>{profile.ownerName}</h3>
        <p><strong>Phone:</strong> {profile.phoneno}</p>
        <p><strong>Status:</strong> {profile.status ? 'Active' : 'Inactive'}</p>
        <p><strong>Verification:</strong> {profile.isValid ? 'Verified Partner' : 'Unverified'}</p>
      </div>

      <div className="address-section">
        <h3>Address</h3>
        {address ? (
          <>
            <p><strong>Address1:</strong> {address.Address1}</p>
            {address.Address2 && <p><strong>Address2:</strong> {address.Address2}</p>}
          </>
        ) : (
          <p>No address found.</p>
        )}

        {shouldShowAddButton && !showAddressForm && (
          <button onClick={() => setShowAddressForm(true)}>Add Address</button>
        )}

        {showAddressForm && (
          <div className="add-address-form">
            <input
              type="text"
              placeholder="Enter new address"
              value={newAddress}
              onChange={(e) => setNewAddress(e.target.value)}
            />
            <button onClick={addAddress}>Submit Address</button>
          </div>
        )}
      </div>

      <div className="profile-stats">
        <h3>Operational Info</h3>
        <p><strong>Orders Served:</strong> {orderCount}</p>
        <p><strong>Menu:</strong> <a href="/restaurant/ManageMenu">View Menu</a></p>
        <p><strong>Order History:</strong> <a href="/restaurant/OrderHistory">View History</a></p>
      </div>
    </div>
  );
};

export default RestaurantProfile;
