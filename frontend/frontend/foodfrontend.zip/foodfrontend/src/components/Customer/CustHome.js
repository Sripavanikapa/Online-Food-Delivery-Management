

import CustNavbar from './CustNavbar/CustNavbar';
import CustAnimation from './CustAnimation/CustAnimation';
import CustBackground from './CustBackground/CustBackground';
import './CustHome.css';
import  CustServices  from './CustServices/CustServices';
import CustFooter from './CustFooter/CustFooter';
import CustCategory from './CustCategory/CustCategory';
import CustBrands from './CustBrands/CustBrands';

import React, { useRef, useEffect } from 'react';
import { useLocation } from 'react-router-dom';

function CustHome() {

  
const categoryRef = useRef(null);
const serviceRef = useRef(null);
const brandsRef = useRef(null);
 const contactRef = useRef(null);
  const location = useLocation();

  useEffect(() => {
    if (location.hash === '#category-section') {
      categoryRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
     if (location.hash === '#contact-section') {
      contactRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
     if (location.hash === '#brands-section') {
      brandsRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
     

  }, [location]);

  return (
    <div className="App">
      <div className='navbar-div'>
        <CustNavbar></CustNavbar>
      </div>
      <div className='background-div'>
            <CustBackground></CustBackground>
      </div>
   <div className='Animation-div'>
     <CustAnimation></CustAnimation>
     </div>
    <div className='Category-div' ref={categoryRef} id='category-section'>
       <CustCategory />
     </div>
     <div className='brands-div' >
         <CustBrands></CustBrands>
     </div>
     <div className="custservices-div" ref={brandsRef} id='brands-section'>
      <CustServices></CustServices>
     </div>
     <div className='custFooter-div' ref={contactRef} id='contact-section'>
       <CustFooter></CustFooter>
     </div>
    </div>
  );
}

export default CustHome;
