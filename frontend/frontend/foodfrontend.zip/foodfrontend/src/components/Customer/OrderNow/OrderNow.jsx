 import React, { useEffect, useState } from 'react';
import { useLocation ,useNavigate} from 'react-router-dom';
import cart from '../../../assets/addtocart.png';
import CustNavbar from '../CustNavbar/CustNavbar'; 
import './OrderNow.css';

const OrderNow = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const itemId = searchParams.get('itemId');
  const restaurantId = searchParams.get('restaurantId');

  const [foodItem, setFoodItem] = useState(null);
  const [addresses, setAddresses] = useState([]);
  const [selectedAddressId, setSelectedAddressId] = useState('');
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [showAddInput, setShowAddInput] = useState(false);
  const [newAddress, setNewAddress] = useState('');
  

  const userId = localStorage.getItem('userId');
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchFoodItem = async () => {
      try {
        const res = await fetch(`https://localhost:7025/api/FoodItem/get/fooditembyid?foodid=${itemId}`);
        const data = await res.json();
        setFoodItem(data);
      } catch (error) {
        console.error('Error fetching food item:', error);
      }
    };

      const fetchAddresses = async () => {
        try {
          const res = await fetch(`https://localhost:7025/get/alladdress/users?userid=${userId}`, {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });
          const data = await res.json();
          setAddresses(data);
        } catch (error) {
          console.error('Error fetching addresses:', error);
        }
      };

      if (itemId) fetchFoodItem();
      if (userId && restaurantId) fetchAddresses();
    }, [itemId, userId, restaurantId]);

        const handleOrderSubmit = async () => {
    try {
      const payload = {
        
          userId: parseInt(userId),
          restaurantId: parseInt(restaurantId),
          itemId: parseInt(itemId),
          custAddressId: parseInt(selectedAddressId),
          status: "Ordered",
         Date: new Date().toISOString()

      };

      const res = await fetch('https://localhost:7025/api/Customer/OrderNow', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      if (!res.ok) throw new Error('Failed to place order');

      //  Remove only the ordered item from cart
      const cart = JSON.parse(localStorage.getItem('cart')) || [];
      const updatedCart = cart.filter(item => item.itemId !== payload.itemId);
      localStorage.setItem('cart', JSON.stringify(updatedCart));

      setOrderPlaced(true);
    } catch (error) {
      console.error('Error placing order:', error);
      alert('Failed to place order. Please try again.');
    }
  };

        useEffect(() => {
        if (orderPlaced) {
          alert("Order Placed Successfully");
        }
      }, [orderPlaced]);


             //Add a new Address  

                            
              const handleAddAddress = async () => {
                  if (!newAddress.trim()) {
                    alert("Please enter a valid address.");
                    return;
                  }

                  try {
                    const payload = {
                      useid: parseInt(userId),
                      address1: newAddress
                    };

                    const res = await fetch('https://localhost:7025/api/Address/create/address', {
                      method: 'POST',
                      headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                      },
                      body: JSON.stringify(payload)
                    });

                    if (!res.ok) {
                      throw new Error("Server responded with an error.");
                    }

                    const resultText = await res.text(); // plain address string

                    alert("Address added successfully.");
                    setNewAddress('');
                    setShowAddInput(false);

                    // ✅ Re-fetch all addresses to get the new one with its ID
                    const updatedRes = await fetch(`https://localhost:7025/get/alladdress/users?userid=${userId}`, {
                      headers: { 'Authorization': `Bearer ${token}` }
                    });
                    const updatedData = await updatedRes.json();
                    setAddresses(updatedData);
                  } catch (error) {
                    console.error('Error adding address:', error);
                    alert(`Failed to add address. ${error.message}`);
                  }
                };



             //Handling delete address 

              const handleDeleteAddress = async (addressId) => {
          const confirmDelete = window.confirm("Are you sure you want to delete this address?");
          if (!confirmDelete) return;

          try {
            console.log("Trying to delete address ID:", addressId);
            const res = await fetch(`https://localhost:7025/api/Address/delete/address?id=${addressId}`, {
              method: 'DELETE',
              headers: {
                 'Content-Type': 'application/json',
                   'Authorization': `Bearer ${token}`
              }
            });

                   const resultText = await res.text(); 
                   const result = resultText.trim().toLowerCase() === 'true'; 

            if (result === true) {
              // Remove the address from the list
              setAddresses(prev => prev.filter(addr => addr.addressId !== addressId));
              alert("Address deleted successfully.");
            } else {
              throw new Error("Address could not be deleted.");
            }
          } catch (error) {
            console.error('Error deleting address:', error);
            alert(`Failed to delete address. ${error.message}`);
          }
        };




        //cart details

        const navigate = useNavigate();

  
                  const [cartCount, setCartCount] = useState(0);
      
                const handleAddToCart = (item) => {
                  const existingCart = JSON.parse(localStorage.getItem('cart')) || [];
                  const updatedCart = [...existingCart, item];
                  localStorage.setItem('cart', JSON.stringify(updatedCart));
                   setCartCount(updatedCart.length); 
                  alert(`${item.itemName} added to cart!`);
                };
             
                const goToCartPage = () => {
                  navigate('/cart');
                };
      
              useEffect(() => {
           const cart = JSON.parse(localStorage.getItem('cart')) || [];
           setCartCount(cart.length);
              }, []);


  return (
    <div className="order-page">

      <div className='navbar-order'>
        <CustNavbar/>
        
      </div>
     
     <div className='order-header'>
       <h2>Order Summary</h2>
       <button className="cart-button" onClick={goToCartPage}><img id='cart-image' src={cart} alt='cart'/>{cartCount}</button>
     </div>

      {foodItem && (
        
        <div className="order-summary">
           
          <img src={foodItem.imageurl} alt={foodItem.foodName} className="order-image" />
          <div className="order-details">
            <h3>{foodItem.foodName}{foodItem.itemName}</h3>
            <p>{foodItem.description}</p>
            <p><strong>Price:</strong> ₹{foodItem.price}</p>
          </div>
        </div>
      )}

            <div className='address-order'>
  <h3>Select Delivery Address:</h3>


            {/* add a new address */}


              <div className="add-address-section">
              {!showAddInput ? (
  
                  <div className="add-address-container">
                    <button onClick={() => setShowAddInput(true)} className="add-address-btn">
                      + Add Address
                    </button>
                  </div>
                   

              ) : (
                <div className="add-address-form">
                  <input
                    type="text"
                    value={newAddress}
                    onChange={(e) => setNewAddress(e.target.value)}
                    placeholder="Enter new address"
                    className="add-address-input"
                  />
                  <button onClick={handleAddAddress} className="add-address-btn">Save</button>
                  <button onClick={() => {
                    setShowAddInput(false);
                    setNewAddress('');
                  }} className="cancel-address-btn">Cancel</button>
                </div>
              )}
            </div>



  {/* display all addresses */}

                    <div className="address-list">
                    {addresses.length === 0 ? (
                      <p>No addresses found. Please add one.</p>
                    ) : (
                      addresses.map(addr => (
                        <div key={addr.addressId} className="address-card">
                                <div className="address-left">
                                  <input
                                    type="checkbox"
                                    checked={selectedAddressId === addr.addressId.toString()}
                                    onChange={() => setSelectedAddressId(addr.addressId.toString())}
                                  />
                                  <span>{addr.address}</span>
                                </div>

                                <button className="delete-btn" onClick={() => handleDeleteAddress(addr.addressId)}>
                                  Delete
                                </button>
                              </div>
                      ))
                    )}
                  </div>

  <br />
  <button
    onClick={handleOrderSubmit}
    disabled={!selectedAddressId}
    className="confirm-order-button"
  >
    Confirm Order
  </button>
</div>
    </div>
  );
};

export default OrderNow;