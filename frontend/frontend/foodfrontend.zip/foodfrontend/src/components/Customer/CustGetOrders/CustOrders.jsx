import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './CustOrders.css';
import CustSearchBarNavbar from '../CustSearchBar/CustSearchBarNavbar';
import cart from '../../../assets/addtocart.png';

const CustOrders = () => {
  const [orders, setOrders] = useState([]);
  const userId = localStorage.getItem('userId');

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const res = await fetch(`https://localhost:7025/api/Customer/Orders?userid=${userId}`);
        const data = await res.json();
        setOrders(data);
      } catch (error) {
        console.error('Error fetching orders:', error);
      }
    };

    if (userId) fetchOrders();
  }, [userId]);



   const navigate = useNavigate();

  
                  const [cartCount, setCartCount] = useState(0);
      
                const handleAddToCart = (item) => {
                  const existingCart = JSON.parse(localStorage.getItem('cart')) || [];
                  const updatedCart = [...existingCart, item];
                  localStorage.setItem('cart', JSON.stringify(updatedCart));
                   setCartCount(updatedCart.length); 
                  alert(`${item.itemName} added to cart!`);
                };
             
                const goToCartPage = () => {
                  navigate('/cart');
                };
      
              useEffect(() => {
           const cart = JSON.parse(localStorage.getItem('cart')) || [];
           setCartCount(cart.length);
              }, []);


  return (

    <div class='custorders-main'>
      <div class='custorders-navbar'>
        <CustSearchBarNavbar></CustSearchBarNavbar>
      </div>
    <div className="orders-container">
      <h2>Your Previous Orders</h2>
       <button className="cart-button" onClick={goToCartPage}><img id='cart-image' src={cart} alt='cart'/>{cartCount}</button>
      {orders.length === 0 ? (
        <p>No orders found.</p>
        
      ) : (
        <div className="orders-list">
          {orders.map((order, index) => (
            <div key={index} className="order-card">
              <img src={order.imageurl} alt={order.itemName} className="order-img" />
              <div className="order-info">
                <h3>{order.itemName}</h3>
                <p><strong>Restaurant:</strong> {order.restaurantName}</p>
                <p><strong>Price:</strong> ₹{order.price}</p>
                <p><strong>Status:</strong> {order.status}</p>
                <p><strong>Date:</strong> {new Date(order.date).toLocaleString()}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
    </div>
  );
};

export default CustOrders;