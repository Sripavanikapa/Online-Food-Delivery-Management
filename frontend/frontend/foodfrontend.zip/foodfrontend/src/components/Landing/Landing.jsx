import React from 'react';
import heroImage from '../../assets/heroImage.png';
import './Landing.css'; // Import the CSS file
import { useNavigate } from 'react-router-dom';
import service1 from '../../assets/service1.png';
import service2 from '../../assets/service2.png';
import service3 from '../../assets/service2.png';

import CustFooter from '../Customer/CustFooter/CustFooter';
import CustServices from '../Customer/CustServices/CustServices';
const Landing = () => {
    const Navigate=useNavigate();
    const handleLoginClick = () => {
    Navigate('/login'); // Navigate to login page
    
  };
  const handleCustomerClick = () =>{
      Navigate('/customer')
    }
  return (
    <div className="landing-container">
      <nav className="navbar">
        <div className="logo">Foodeli</div>
        <ul className="nav-links">
          <li><a href="#why">Why Foodeli?</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#categories">Categories</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
        <button className="login-btn" onClick={handleLoginClick}>Login</button>
      </nav>

      <section className="hero-section">
        <div className="hero-text">
          <h1>Claim Best Offer on Fast Food & Restaurants</h1>
          <p>Our job is to filling your tummy with delicious food and with fast and free delivery</p>
          <button className="cta-btn" onClick={handleCustomerClick}>Get Started</button>
        </div>
        <div className="hero-image">
          <img src={heroImage} alt="Delicious food" />
        </div>
      </section>
      <section>
            <CustServices/>
      </section>
      <section>
        <div id='footer-landing'>
                   <CustFooter/>
        </div>
           
      </section>

    </div>
  );
};

export default Landing;
